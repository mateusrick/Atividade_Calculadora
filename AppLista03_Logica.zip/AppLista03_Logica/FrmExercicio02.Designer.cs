﻿namespace AppLista03_Logica
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrecoG = new System.Windows.Forms.Label();
            this.lblPago = new System.Windows.Forms.Label();
            this.TxtGasolina = new System.Windows.Forms.TextBox();
            this.txtPago = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPrecoG
            // 
            this.lblPrecoG.AutoSize = true;
            this.lblPrecoG.ForeColor = System.Drawing.Color.Black;
            this.lblPrecoG.Location = new System.Drawing.Point(246, 109);
            this.lblPrecoG.Name = "lblPrecoG";
            this.lblPrecoG.Size = new System.Drawing.Size(79, 13);
            this.lblPrecoG.TabIndex = 0;
            this.lblPrecoG.Text = "Preço Gasolina";
            // 
            // lblPago
            // 
            this.lblPago.AutoSize = true;
            this.lblPago.ForeColor = System.Drawing.Color.Black;
            this.lblPago.Location = new System.Drawing.Point(456, 109);
            this.lblPago.Name = "lblPago";
            this.lblPago.Size = new System.Drawing.Size(59, 13);
            this.lblPago.TabIndex = 1;
            this.lblPago.Text = "Valor Pago";
            // 
            // TxtGasolina
            // 
            this.TxtGasolina.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtGasolina.Location = new System.Drawing.Point(234, 167);
            this.TxtGasolina.Name = "TxtGasolina";
            this.TxtGasolina.Size = new System.Drawing.Size(100, 31);
            this.TxtGasolina.TabIndex = 2;
            this.TxtGasolina.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtPago
            // 
            this.txtPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPago.Location = new System.Drawing.Point(433, 167);
            this.txtPago.Name = "txtPago";
            this.txtPago.Size = new System.Drawing.Size(100, 31);
            this.txtPago.TabIndex = 3;
            this.txtPago.TextChanged += new System.EventHandler(this.txtPago_TextChanged);
            // 
            // btnCalcular
            // 
            this.btnCalcular.ForeColor = System.Drawing.Color.Black;
            this.btnCalcular.Location = new System.Drawing.Point(348, 274);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(255)))), ((int)(((byte)(191)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPago);
            this.Controls.Add(this.TxtGasolina);
            this.Controls.Add(this.lblPago);
            this.Controls.Add(this.lblPrecoG);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.Load += new System.EventHandler(this.FrmExercicio02_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrecoG;
        private System.Windows.Forms.Label lblPago;
        private System.Windows.Forms.TextBox TxtGasolina;
        private System.Windows.Forms.TextBox txtPago;
        private System.Windows.Forms.Button btnCalcular;
    }
}