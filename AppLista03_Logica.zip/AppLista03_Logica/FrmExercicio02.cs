﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void FrmExercicio02_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           

            

        }

        private void txtPago_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float vlpago = float.Parse(txtPago.Text);
            float gasolina = float.Parse(TxtGasolina.Text);
            float calcular;

            calcular = vlpago / gasolina;

            MessageBox.Show("valor em litros = " + calcular); 
        }
    }
}
