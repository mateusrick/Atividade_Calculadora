﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class lblN3 : Form
    {
        public lblN3()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtN2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtN1.Text);
            float num3 = float.Parse(txtN3.Text);
            float soma;

            soma = num1 + num3;

            MessageBox.Show("soma = " + soma);

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtN1.Text);
            float num2 = float.Parse(txtN2.Text);
            float num3 = float.Parse(txtN3.Text);
            float media;

            media = (num1 + num2 + num3)/3;

            MessageBox.Show("Media = " + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtN1.Text);
            float num2 = float.Parse(txtN2.Text);
            float num3 = float.Parse(txtN3.Text);
            float Porcentagem1, Porcentagem2, Porcentagem3;

            Porcentagem1 = num1 / (num1 + num2 + num3) * 100;
            Porcentagem2 = num2 / (num1 + num2 + num3) * 100;
            Porcentagem3 = num3 / (num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentagem igual a = " + Porcentagem1);
            MessageBox.Show("Porcentagem igual a = " + Porcentagem2);
            MessageBox.Show("Porcentagem igual a = " + Porcentagem3);

        }
    }
}
